package com.example.simplelistview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
public class MainActivity extends AppCompatActivity {
    String[] mobileArray = {"Android","iOS","WindowsMobile","Blackberry", "WebOS","Ubuntu",
            "Windows","Max OS X"};
    ListView operatingSystemList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.layout,mobileArray);
        operatingSystemList = (ListView) findViewById(R.id.mobile_list);
        operatingSystemList.setAdapter(adapter);
    }
}


